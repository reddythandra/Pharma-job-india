# Pharma Jobs India — free starter website

A responsive static job-listings website built with plain HTML, CSS and JavaScript. No database, paid hosting, framework or build step is required.

## 1. Preview locally
- Extract `pharma_jobs_india.zip`.
- Open `index.html` in Chrome, Edge or Firefox.

## 2. Replace demo listings before publishing
Open `index.html` in a text editor and find `const jobs = [`.
Replace the sample objects with verified vacancies. Each job uses:
- `title`: job title
- `company`: employer name
- `location`: city and state
- `department`: Quality Control, Quality Assurance, Production, R&D, Microbiology, CSV / CSA, Regulatory Affairs, or another department
- `experience`: Fresher, 0–2 years, 1–3 years, 2–5 years, or 5+ years
- `type`: Full-time, Walk-in, Contract, or Internship
- `date`: date posted
- `skills`: key skills
- `url`: direct official application URL
- `sample`: set to `false` for a real, verified listing

Delete all sample listings or replace them with verified ones before launch. Do not present demo listings as real vacancies.

## 3. Change your contact details
In `index.html`, find and replace:
- `your-email@example.com` with your real contact email
- The `mailto:` address in the Submit a job button uses the same placeholder

The submit button currently opens the visitor's email app. For a no-code submission form, create a Google Form and replace the button's `mailto:` URL with the public form URL.

## 4. Publish free with GitHub Pages
1. Sign in or create a free account at https://github.com/
2. Create a new public repository named `pharma-jobs-india`.
3. Upload `index.html` to the repository's root (not inside another folder).
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/ (root)`, then Save.
7. Wait for the GitHub Pages deployment. The site address will look like:
   `https://YOUR-USERNAME.github.io/pharma-jobs-india/`

GitHub's UI labels may change slightly. Official guide: https://docs.github.com/en/pages/quickstart

## 5. Updating jobs
Edit `index.html` in GitHub, update the `jobs` array, and commit the change. GitHub Pages republishes the site automatically.

## Important limitations
- This starter is a static website. It does not have a private admin dashboard, user accounts, database, automatic job imports, or automatic expiry.
- Job updates are made by editing the jobs array.
- Use official employer application links and verify each vacancy, deadline and location before publishing.
- Never ask candidates to pay a fee for a job. Avoid collecting CVs or personal data until you have a suitable privacy notice and secure process.
- The site is a starter template, not legal advice or a recruitment agency service.
